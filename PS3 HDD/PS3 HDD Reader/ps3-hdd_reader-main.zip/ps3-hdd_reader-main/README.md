# ps3-hdd_reader
modified version of hdd_reader from 3141card
(not finished)

works for FAT NOR console CECHL04
